﻿namespace Homework_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lstTinh_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.txtSo.Focus();
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            int number;
            if (int.TryParse(txtSo.Text, out number))
            {
                cboSo.Items.Add(txtSo.Text);

                txtSo.Clear();
                txtSo.Focus();
            }
            else
            {
                MessageBox.Show("Vui lòng nhập một số hợp lệ!");
                txtSo.Focus();
            }
        }

        private void cboSo_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstTinh.Items.Clear();

            int so = int.Parse(cboSo.SelectedItem.ToString());

            for (int i = 1; i <= so; i++)
            {
                if ((so % i) == 0)
                {
                    lstTinh.Items.Add(i);
                }
            }
        }

        private void btnTong_Click(object sender, EventArgs e)
        {
            int tong = 0;
            for (int i = 0; i < lstTinh.Items.Count; i++)
            {
                tong += int.Parse(lstTinh.Items[i].ToString());
            }
            MessageBox.Show("Tổng các ước số là: " + tong, "Kết quả");
        }

        private void btnChan_Click(object sender, EventArgs e)
        {
            int dem = 0;
            for (int i = 0; i < lstTinh.Items.Count; i++)
            {
                int uocSo = int.Parse(lstTinh.Items[i].ToString());
                if (uocSo % 2 == 0)
                {
                    dem++;
                }
            }
            MessageBox.Show("Số lượng ước số chẵn là: " + dem, "Kết quả");
        }

        private void btnNguyenTo_Click(object sender, EventArgs e)
        {
            int dem = 0;
            for (int i = 0; i < lstTinh.Items.Count; i++)
            {
                int uocSo = int.Parse(lstTinh.Items[i].ToString());
                if (KiemTraNguyenTo(uocSo))
                {
                    dem++;
                }
            }
            MessageBox.Show("Số lượng ước số nguyên tố là: " + dem, "Kết quả");
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public bool KiemTraNguyenTo(int n)
        {
            if (n < 2)
                return false;
            for (int i = 2; i <= Math.Sqrt(n); i++)
            {
                if (n % i == 0)
                    return false;
            }
            return true;
        }
    }
}
