﻿namespace Homework_3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            txtSo = new TextBox();
            btnCapNhat = new Button();
            cboSo = new ComboBox();
            groupBox2 = new GroupBox();
            lstTinh = new ListBox();
            btnThoat = new Button();
            btnTong = new Button();
            btnChan = new Button();
            btnNguyenTo = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtSo);
            groupBox1.Controls.Add(btnCapNhat);
            groupBox1.Controls.Add(cboSo);
            groupBox1.Location = new Point(12, 32);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(446, 268);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Nhập Số";
            // 
            // txtSo
            // 
            txtSo.Location = new Point(6, 67);
            txtSo.Name = "txtSo";
            txtSo.Size = new Size(266, 39);
            txtSo.TabIndex = 3;
            // 
            // btnCapNhat
            // 
            btnCapNhat.Location = new Point(290, 63);
            btnCapNhat.Name = "btnCapNhat";
            btnCapNhat.Size = new Size(150, 46);
            btnCapNhat.TabIndex = 6;
            btnCapNhat.Text = "Cập nhật";
            btnCapNhat.UseVisualStyleBackColor = true;
            btnCapNhat.Click += btnCapNhat_Click;
            // 
            // cboSo
            // 
            cboSo.FormattingEnabled = true;
            cboSo.Location = new Point(6, 140);
            cboSo.Name = "cboSo";
            cboSo.Size = new Size(434, 40);
            cboSo.TabIndex = 4;
            cboSo.SelectedIndexChanged += cboSo_SelectedIndexChanged;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lstTinh);
            groupBox2.Location = new Point(540, 32);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(442, 268);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Danh sách các ước số";
            // 
            // lstTinh
            // 
            lstTinh.FormattingEnabled = true;
            lstTinh.Location = new Point(6, 63);
            lstTinh.Name = "lstTinh";
            lstTinh.Size = new Size(430, 132);
            lstTinh.TabIndex = 5;
            // 
            // btnThoat
            // 
            btnThoat.Location = new Point(18, 431);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(440, 46);
            btnThoat.TabIndex = 5;
            btnThoat.Text = "Thoát";
            btnThoat.UseVisualStyleBackColor = true;
            btnThoat.Click += btnThoat_Click;
            // 
            // btnTong
            // 
            btnTong.Location = new Point(546, 345);
            btnTong.Name = "btnTong";
            btnTong.Size = new Size(436, 46);
            btnTong.TabIndex = 2;
            btnTong.Text = "Tổng các ước số";
            btnTong.UseVisualStyleBackColor = true;
            btnTong.Click += btnTong_Click;
            // 
            // btnChan
            // 
            btnChan.Location = new Point(546, 431);
            btnChan.Name = "btnChan";
            btnChan.Size = new Size(436, 46);
            btnChan.TabIndex = 3;
            btnChan.Text = "Số lượng các ước số chẵn";
            btnChan.UseVisualStyleBackColor = true;
            btnChan.Click += btnChan_Click;
            // 
            // btnNguyenTo
            // 
            btnNguyenTo.Location = new Point(546, 513);
            btnNguyenTo.Name = "btnNguyenTo";
            btnNguyenTo.Size = new Size(430, 46);
            btnNguyenTo.TabIndex = 4;
            btnNguyenTo.Text = "Số lượng các ước số nguyên tố";
            btnNguyenTo.UseVisualStyleBackColor = true;
            btnNguyenTo.Click += btnNguyenTo_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(994, 610);
            Controls.Add(btnNguyenTo);
            Controls.Add(btnChan);
            Controls.Add(btnTong);
            Controls.Add(btnThoat);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "ComboBox";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private TextBox txtSo;
        private ComboBox cboSo;
        private ListBox lstTinh;
        private Button btnCapNhat;
        private Button btnThoat;
        private Button btnTong;
        private Button btnChan;
        private Button btnNguyenTo;
    }
}
