﻿namespace Homework_4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtSo1 = new TextBox();
            txtSo2 = new TextBox();
            txtKetQua = new TextBox();
            groupBox1 = new GroupBox();
            radChia = new RadioButton();
            radNhan = new RadioButton();
            radTru = new RadioButton();
            radCong = new RadioButton();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(45, 23);
            label1.Name = "label1";
            label1.Size = new Size(66, 32);
            label1.TabIndex = 0;
            label1.Text = "Số 1:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(45, 76);
            label2.Name = "label2";
            label2.Size = new Size(66, 32);
            label2.TabIndex = 1;
            label2.Text = "Số 2:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(45, 317);
            label3.Name = "label3";
            label3.Size = new Size(101, 32);
            label3.TabIndex = 2;
            label3.Text = "Kết quả:";
            // 
            // txtSo1
            // 
            txtSo1.Location = new Point(147, 20);
            txtSo1.Name = "txtSo1";
            txtSo1.Size = new Size(436, 39);
            txtSo1.TabIndex = 4;
            // 
            // txtSo2
            // 
            txtSo2.Location = new Point(147, 73);
            txtSo2.Name = "txtSo2";
            txtSo2.Size = new Size(436, 39);
            txtSo2.TabIndex = 5;
            // 
            // txtKetQua
            // 
            txtKetQua.Location = new Point(152, 314);
            txtKetQua.Name = "txtKetQua";
            txtKetQua.ReadOnly = true;
            txtKetQua.Size = new Size(431, 39);
            txtKetQua.TabIndex = 6;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(radChia);
            groupBox1.Controls.Add(radNhan);
            groupBox1.Controls.Add(radTru);
            groupBox1.Controls.Add(radCong);
            groupBox1.Location = new Point(45, 138);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(538, 142);
            groupBox1.TabIndex = 7;
            groupBox1.TabStop = false;
            groupBox1.Text = "Phép tính";
            // 
            // radChia
            // 
            radChia.AutoSize = true;
            radChia.Location = new Point(410, 66);
            radChia.Name = "radChia";
            radChia.Size = new Size(92, 36);
            radChia.TabIndex = 3;
            radChia.Text = "Chia";
            radChia.UseVisualStyleBackColor = true;
            radChia.CheckedChanged += radChia_CheckedChanged;
            // 
            // radNhan
            // 
            radNhan.AutoSize = true;
            radNhan.Location = new Point(267, 66);
            radNhan.Name = "radNhan";
            radNhan.Size = new Size(103, 36);
            radNhan.TabIndex = 2;
            radNhan.Text = "Nhân";
            radNhan.UseVisualStyleBackColor = true;
            radNhan.CheckedChanged += radNhan_CheckedChanged;
            // 
            // radTru
            // 
            radTru.AutoSize = true;
            radTru.Location = new Point(145, 66);
            radTru.Name = "radTru";
            radTru.Size = new Size(78, 36);
            radTru.TabIndex = 1;
            radTru.Text = "Trừ";
            radTru.UseVisualStyleBackColor = true;
            radTru.CheckedChanged += radTru_CheckedChanged;
            // 
            // radCong
            // 
            radCong.AutoSize = true;
            radCong.Checked = true;
            radCong.Location = new Point(6, 66);
            radCong.Name = "radCong";
            radCong.Size = new Size(102, 36);
            radCong.TabIndex = 0;
            radCong.TabStop = true;
            radCong.Text = "Cộng";
            radCong.UseVisualStyleBackColor = true;
            radCong.CheckedChanged += radCong_CheckedChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(630, 450);
            Controls.Add(groupBox1);
            Controls.Add(txtKetQua);
            Controls.Add(txtSo2);
            Controls.Add(txtSo1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Phép tính\t";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtSo1;
        private TextBox txtSo2;
        private TextBox txtKetQua;
        private GroupBox groupBox1;
        private RadioButton radChia;
        private RadioButton radNhan;
        private RadioButton radTru;
        private RadioButton radCong;
    }
}
