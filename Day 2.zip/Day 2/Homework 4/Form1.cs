﻿namespace Homework_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void TinhToan()
        {
            double so1, so2;

            if (double.TryParse(txtSo1.Text, out so1) && double.TryParse(txtSo2.Text, out so2))
            {
                double ketQua = 0;

                if (radCong.Checked)
                {
                    ketQua = so1 + so2;
                }
                else if (radTru.Checked)
                {
                    ketQua = so1 - so2;
                }
                else if (radNhan.Checked)
                {
                    ketQua = so1 * so2;
                }
                else if (radChia.Checked)
                {
                    if (so2 != 0)
                    {
                        ketQua = so1 / so2;
                    }
                    else
                    {
                        MessageBox.Show("Không thể chia cho 0!", "Lỗi");
                        txtKetQua.Clear();
                        return;
                    }
                }

                txtKetQua.Text = ketQua.ToString();
            }
            else
            {
                txtKetQua.Clear();
            }
        }

        private void radCong_CheckedChanged(object sender, EventArgs e)
        {
            TinhToan();
        }

        private void radTru_CheckedChanged(object sender, EventArgs e)
        {
            TinhToan();
        }

        private void radNhan_CheckedChanged(object sender, EventArgs e)
        {
            TinhToan();
        }

        private void radChia_CheckedChanged(object sender, EventArgs e)
        {
            TinhToan();
        }
    }
}
