﻿namespace Homework_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtHoTen = new TextBox();
            txtKQ = new TextBox();
            groupBox1 = new GroupBox();
            rad2 = new RadioButton();
            rad1 = new RadioButton();
            btnKQ = new Button();
            btnX = new Button();
            btnD = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(31, 50);
            label1.Name = "label1";
            label1.Size = new Size(231, 36);
            label1.TabIndex = 0;
            label1.Text = "Nhập Họ và Tên:";
            // 
            // txtHoTen
            // 
            txtHoTen.Location = new Point(285, 47);
            txtHoTen.Name = "txtHoTen";
            txtHoTen.Size = new Size(482, 44);
            txtHoTen.TabIndex = 1;
            // 
            // txtKQ
            // 
            txtKQ.Location = new Point(285, 384);
            txtKQ.Name = "txtKQ";
            txtKQ.Size = new Size(482, 44);
            txtKQ.TabIndex = 2;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rad2);
            groupBox1.Controls.Add(rad1);
            groupBox1.Location = new Point(31, 136);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(590, 200);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            groupBox1.Text = "Chọn kiểu chữ";
            // 
            // rad2
            // 
            rad2.AutoSize = true;
            rad2.Location = new Point(52, 116);
            rad2.Name = "rad2";
            rad2.Size = new Size(233, 40);
            rad2.TabIndex = 1;
            rad2.Text = "CHỮ IN HOA";
            rad2.UseVisualStyleBackColor = true;
            // 
            // rad1
            // 
            rad1.AutoSize = true;
            rad1.Checked = true;
            rad1.Location = new Point(52, 56);
            rad1.Name = "rad1";
            rad1.Size = new Size(188, 40);
            rad1.TabIndex = 0;
            rad1.TabStop = true;
            rad1.Text = "chữ thường";
            rad1.UseVisualStyleBackColor = true;
            // 
            // btnKQ
            // 
            btnKQ.Location = new Point(31, 384);
            btnKQ.Name = "btnKQ";
            btnKQ.Size = new Size(231, 46);
            btnKQ.TabIndex = 4;
            btnKQ.Text = "Kết quả";
            btnKQ.UseVisualStyleBackColor = true;
            btnKQ.Click += button1_Click;
            // 
            // btnX
            // 
            btnX.Location = new Point(627, 151);
            btnX.Name = "btnX";
            btnX.Size = new Size(140, 185);
            btnX.TabIndex = 5;
            btnX.Text = "Xóa";
            btnX.UseVisualStyleBackColor = true;
            btnX.Click += btnX_Click;
            // 
            // btnD
            // 
            btnD.Location = new Point(31, 448);
            btnD.Name = "btnD";
            btnD.Size = new Size(736, 46);
            btnD.TabIndex = 6;
            btnD.Text = "Dừng";
            btnD.UseVisualStyleBackColor = true;
            btnD.Click += btnD_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(18F, 36F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            ClientSize = new Size(814, 506);
            Controls.Add(btnD);
            Controls.Add(btnX);
            Controls.Add(btnKQ);
            Controls.Add(groupBox1);
            Controls.Add(txtKQ);
            Controls.Add(txtHoTen);
            Controls.Add(label1);
            Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(4, 3, 4, 3);
            Name = "Form1";
            Text = "Đổi kiểu chữ";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtHoTen;
        private TextBox txtKQ;
        private GroupBox groupBox1;
        private RadioButton rad2;
        private RadioButton rad1;
        private Button btnKQ;
        private Button btnX;
        private Button btnD;
    }
}
